﻿using System;
using System.Collections;
using System.Configuration;
using System.Net;
using System.Net.Configuration;
using System.Net.Mail;
using System.Net.Mime;
using System.Text.RegularExpressions;



namespace Enviar_Email
{
    public class Email
    {
        public static string EnviarMensagemEmail(string Destinatario,  string Assunto, string EnviaMensagem, string CopiaOculta, string Copia)
        {
            try
            {
                //Representa uma mensagem de email (string from, string to, string subject, string body)
                MailMessage MensagemDeEmail = new MailMessage("stringnome@gmail.com", Destinatario, Assunto, EnviaMensagem);

                //Se Campo Destinatario Com Copia preenchido  Adicionar uma Copia Para DestinatarioCC
                if ((Copia != null) && (Copia != ""))
                {
                    MailAddress Copiapara = new MailAddress(Copia);
                    MensagemDeEmail.CC.Add(Copiapara);
                }
                //Se Campo Destinarario Com Copia Oculta preenchido Adicionar uma Copia Oculta para DestinatarioBcc
                if ((CopiaOculta != null) && (CopiaOculta != ""))
                {
                    MailAddress CopiaOcultapara = new MailAddress(CopiaOculta);
                    MensagemDeEmail.Bcc.Add(CopiaOcultapara);
                }

                //Envia  E-mail usando o servidor SMTP e porta especificados.
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);

                // habilitado conexão de segurança
                client.EnableSsl = true;

                //Tempo de resposta 
                client.Timeout = 10000;

                //Especifica como saída mensagens de e-mail serão tratadas.
                //SmtpDeliveryMethod.Network propriedade para especificar o método de entrega.
                client.DeliveryMethod = SmtpDeliveryMethod.Network;

                //true se as credenciais padrão são usadas; se não false. O valor padrão é false. 
                client.UseDefaultCredentials = false;

                //define as credenciais de rede que são enviados para o host e usadas para autenticar a solicitação.
                client.Credentials = new NetworkCredential("stringnome@gmail.com", "M46#@w0*55");

                //Enviar Mensagem 
                client.Send(MensagemDeEmail);

                return "Mensagem enviada às " + DateTime.Now.ToString() + ".";
            }
            catch (Exception ex)
            {
                string erro = ex.InnerException.ToString();
                return ex.Message.ToString() + erro;
            }

        }

        public static string EnviarMensagemComAnexos(string Destinatario,  string Assunto, string EnviaMensagem, string CopiaOculta, string Copia, ArrayList anexos)
        {
            try
            {
                //Representa uma mensagem de email , parametros(string from, string to, string subject, string body)
                MailMessage MensagemDeEmail = new MailMessage("stringnome@gmail.com", Destinatario, Assunto, EnviaMensagem);
                if ((Copia != null) && (Copia != ""))
                {
                    MailAddress Copiapara = new MailAddress(Copia);
                    MensagemDeEmail.CC.Add(Copiapara);
                }
                if ((CopiaOculta != null) && (CopiaOculta != ""))
                {
                    MailAddress CopiaOcultapara = new MailAddress(CopiaOculta);
                    MensagemDeEmail.Bcc.Add(CopiaOcultapara);
                }

                foreach (string anexo in anexos)
                {
                    //( anexado ) Representa um anexo em um email.
                    //MediaTypeNames.Application Especifica o tipo de dados do aplicativo em um anexo de email.
                    Attachment anexado = new Attachment(anexo, MediaTypeNames.Application.Octet);
                    MensagemDeEmail.Attachments.Add(anexado);
                }

                //Envia  E-mail usando o servidor SMTP e porta especificados.
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);

                // habilitado conexão de segurança
                client.EnableSsl = true;

                //Tempo de resposta 
                client.Timeout = 10000;

                //Especifica como saída mensagens de e-mail serão tratadas.
                //SmtpDeliveryMethod.Network propriedade para especificar o método de entrega.
                client.DeliveryMethod = SmtpDeliveryMethod.Network;

                //true se as credenciais padrão são usadas; se não false. O valor padrão é false. 
                client.UseDefaultCredentials = false;

                //define as credenciais de rede que são enviados para o host e usadas para autenticar a solicitação.
                client.Credentials = new NetworkCredential("stringnome@gmail.com", "M46#@w0*55");

                //Enviar Mensagem 
                client.Send(MensagemDeEmail);

                return "Mensagem enviada às " + DateTime.Now.ToString() + ".";
            }
            catch (Exception ex)
            {
                string erro = ex.InnerException.ToString();
                return ex.Message.ToString() + erro;
            }
        }

    }
}
