﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Enviar_Email
{
    public partial class Form1 : Form
    {
       //Armazenar os aneos
        ArrayList aAnexosEmail;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog ofd = new OpenFileDialog();

                //Permite que vários arquivos a serem selecionados.
                ofd.Multiselect = true;

                //Criando titulo para janela 
                ofd.Title = "Inserir Anexo(s)";

                aAnexosEmail = new ArrayList();

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    foreach (String file in ofd.SafeFileNames)
                    {
                        //adiciona item a item
                        listBox1.Items.Add(file);
                    }
                    //Inclui Todos os arquivos no Arraylist 
                    aAnexosEmail.AddRange(ofd.FileNames);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro no aplicativo ! Detalhes : "+ ex.Message,"Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

         }
       
        private void btnEnviar_Click(object sender, EventArgs e)
        {
            try
            {
                //Se o arquivo contem anexos EnviarMensagemComAnexos()
                if (aAnexosEmail != null)
                {
                    string resultado = Enviar_Email.Email.EnviarMensagemComAnexos(txtEnviarPara.Text, txtAssuntoTitulo.Text, txtMensagem.Text, txtCopiaOculta.Text, txtCopia.Text, aAnexosEmail);
                    MessageBox.Show(resultado, "Email enviado com sucesso ");
                }
                //Enviar Mensagem nomal 
                else
                {
                    string resultado = Enviar_Email.Email.EnviarMensagemEmail(txtEnviarPara.Text, txtAssuntoTitulo.Text, txtMensagem.Text, txtCopiaOculta.Text, txtCopia.Text);
                    MessageBox.Show(resultado, "Email enviado com sucesso");
                }
            }
          
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro no Aplicativo ! Detalhes: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            //Representa o item Selecionado 
            int item = listBox1.SelectedIndex;

            //Remove o item Selecioando 
            aAnexosEmail.Remove(aAnexosEmail[item]);
            
            //Remove item selecionado da listbox
            listBox1.Items.Remove(listBox1.SelectedItem);
        }
    }
}
