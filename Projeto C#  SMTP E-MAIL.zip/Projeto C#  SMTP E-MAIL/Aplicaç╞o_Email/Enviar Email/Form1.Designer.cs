﻿namespace Enviar_Email
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grpAnexos = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRemover = new System.Windows.Forms.Button();
            this.btnIncluir = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.grpDestinatario = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCopiaOculta = new System.Windows.Forms.TextBox();
            this.txtCopia = new System.Windows.Forms.TextBox();
            this.txtEnviarPara = new System.Windows.Forms.TextBox();
            this.grpMensagem = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMensagem = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAssuntoTitulo = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.grpAnexos.SuspendLayout();
            this.grpDestinatario.SuspendLayout();
            this.grpMensagem.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpAnexos
            // 
            this.grpAnexos.Controls.Add(this.label6);
            this.grpAnexos.Controls.Add(this.btnRemover);
            this.grpAnexos.Controls.Add(this.btnIncluir);
            this.grpAnexos.Controls.Add(this.listBox1);
            this.grpAnexos.Location = new System.Drawing.Point(12, 153);
            this.grpAnexos.Name = "grpAnexos";
            this.grpAnexos.Size = new System.Drawing.Size(680, 87);
            this.grpAnexos.TabIndex = 1;
            this.grpAnexos.TabStop = false;
            this.grpAnexos.Text = "Anexo(s)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Arquivos  :";
            // 
            // btnRemover
            // 
            this.btnRemover.BackColor = System.Drawing.SystemColors.Menu;
            this.btnRemover.Location = new System.Drawing.Point(594, 49);
            this.btnRemover.Name = "btnRemover";
            this.btnRemover.Size = new System.Drawing.Size(73, 24);
            this.btnRemover.TabIndex = 4;
            this.btnRemover.Text = "Remover";
            this.btnRemover.UseVisualStyleBackColor = false;
            this.btnRemover.Click += new System.EventHandler(this.btnRemover_Click);
            // 
            // btnIncluir
            // 
            this.btnIncluir.Location = new System.Drawing.Point(594, 19);
            this.btnIncluir.Name = "btnIncluir";
            this.btnIncluir.Size = new System.Drawing.Size(73, 24);
            this.btnIncluir.TabIndex = 2;
            this.btnIncluir.Text = "Adicionar";
            this.btnIncluir.UseVisualStyleBackColor = true;
            this.btnIncluir.Click += new System.EventHandler(this.btnIncluir_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(98, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBox1.Size = new System.Drawing.Size(490, 56);
            this.listBox1.TabIndex = 3;
            // 
            // grpDestinatario
            // 
            this.grpDestinatario.Controls.Add(this.label3);
            this.grpDestinatario.Controls.Add(this.label2);
            this.grpDestinatario.Controls.Add(this.label1);
            this.grpDestinatario.Controls.Add(this.txtCopiaOculta);
            this.grpDestinatario.Controls.Add(this.txtCopia);
            this.grpDestinatario.Controls.Add(this.txtEnviarPara);
            this.grpDestinatario.Location = new System.Drawing.Point(12, 12);
            this.grpDestinatario.Name = "grpDestinatario";
            this.grpDestinatario.Size = new System.Drawing.Size(680, 125);
            this.grpDestinatario.TabIndex = 0;
            this.grpDestinatario.TabStop = false;
            this.grpDestinatario.Text = "Destinatário(s)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Cópia Oculta :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Cópia :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Para : ";
            // 
            // txtCopiaOculta
            // 
            this.txtCopiaOculta.Location = new System.Drawing.Point(98, 83);
            this.txtCopiaOculta.Name = "txtCopiaOculta";
            this.txtCopiaOculta.Size = new System.Drawing.Size(568, 20);
            this.txtCopiaOculta.TabIndex = 2;
            // 
            // txtCopia
            // 
            this.txtCopia.Location = new System.Drawing.Point(98, 57);
            this.txtCopia.Name = "txtCopia";
            this.txtCopia.Size = new System.Drawing.Size(568, 20);
            this.txtCopia.TabIndex = 1;
            // 
            // txtEnviarPara
            // 
            this.txtEnviarPara.Location = new System.Drawing.Point(98, 31);
            this.txtEnviarPara.Name = "txtEnviarPara";
            this.txtEnviarPara.Size = new System.Drawing.Size(568, 20);
            this.txtEnviarPara.TabIndex = 0;
            // 
            // grpMensagem
            // 
            this.grpMensagem.Controls.Add(this.label5);
            this.grpMensagem.Controls.Add(this.txtMensagem);
            this.grpMensagem.Controls.Add(this.label4);
            this.grpMensagem.Controls.Add(this.txtAssuntoTitulo);
            this.grpMensagem.Location = new System.Drawing.Point(12, 246);
            this.grpMensagem.Name = "grpMensagem";
            this.grpMensagem.Size = new System.Drawing.Size(680, 316);
            this.grpMensagem.TabIndex = 0;
            this.grpMensagem.TabStop = false;
            this.grpMensagem.Text = "Mensagem";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Mensagem :";
            // 
            // txtMensagem
            // 
            this.txtMensagem.Location = new System.Drawing.Point(19, 79);
            this.txtMensagem.Multiline = true;
            this.txtMensagem.Name = "txtMensagem";
            this.txtMensagem.Size = new System.Drawing.Size(647, 222);
            this.txtMensagem.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Assunto:";
            // 
            // txtAssuntoTitulo
            // 
            this.txtAssuntoTitulo.Location = new System.Drawing.Point(98, 20);
            this.txtAssuntoTitulo.Name = "txtAssuntoTitulo";
            this.txtAssuntoTitulo.Size = new System.Drawing.Size(568, 20);
            this.txtAssuntoTitulo.TabIndex = 6;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnCancelar.Location = new System.Drawing.Point(512, 578);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(88, 27);
            this.BtnCancelar.TabIndex = 3;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // btnEnviar
            // 
            this.btnEnviar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEnviar.Location = new System.Drawing.Point(606, 578);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(88, 27);
            this.btnEnviar.TabIndex = 2;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.ClientSize = new System.Drawing.Size(704, 617);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.grpMensagem);
            this.Controls.Add(this.grpDestinatario);
            this.Controls.Add(this.grpAnexos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Enviar E-Mail";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpAnexos.ResumeLayout(false);
            this.grpAnexos.PerformLayout();
            this.grpDestinatario.ResumeLayout(false);
            this.grpDestinatario.PerformLayout();
            this.grpMensagem.ResumeLayout(false);
            this.grpMensagem.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpAnexos;
        private System.Windows.Forms.GroupBox grpDestinatario;
        private System.Windows.Forms.GroupBox grpMensagem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCopiaOculta;
        private System.Windows.Forms.TextBox txtCopia;
        private System.Windows.Forms.TextBox txtEnviarPara;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAssuntoTitulo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMensagem;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnIncluir;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button btnRemover;
        private System.Windows.Forms.Label label6;

    }
}

