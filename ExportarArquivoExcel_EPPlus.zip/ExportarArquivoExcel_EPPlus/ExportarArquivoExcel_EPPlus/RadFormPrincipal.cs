﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Telerik.WinControls;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using System.IO;

namespace ExportarArquivoExcel_EPPlus
{
    public partial class RadFormPrincipal : Telerik.WinControls.UI.RadForm
    {
        #region    Váriaveis

        //Armazenar Caminho do arquivo 
        private string strCaminho;

        #endregion Váriaveis

        #region Construtor

        public RadFormPrincipal()
        {
            InitializeComponent();
        }

        #endregion Construtor

        #region Eventos Fórmulario

        private void RadFormPrincipal_Load(object sender, EventArgs e)
        {
            //DataSource 
            dataGridView.DataSource = Produtos(); ;
            var data = DateTime.Now; //pega a data que está no controle
            var mesAnterior = data.AddMonths(-1);
            var primeiroDia = new DateTime(mesAnterior.Year, mesAnterior.Month, 1);
            var ultimoDia   = new DateTime(mesAnterior.Year, mesAnterior.Month,DateTime.DaysInMonth(mesAnterior.Year, mesAnterior.Month));

            dateTimePicker1.Value = primeiroDia;
            dateTimePicker2.Value = ultimoDia;
            
        }

        #endregion Eventos Fórmulario

        #region Eventos Botões 

        private void radButtonExportar_Click(object sender, EventArgs e)
        {
            //Selecionar Caminho
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                //Define caminho
                strCaminho = saveFileDialog.FileName;
                backgroundWorker.RunWorkerAsync();
            }
        }

        #endregion Eventos Botões

        private DataTable Produtos()
        {
            DataTable dataTableProdutos = new DataTable();

            // Adicinando Colunas 
            dataTableProdutos.Columns.Add("Código" ,typeof(string));
            dataTableProdutos.Columns.Add("Produto",typeof(string));
            dataTableProdutos.Columns.Add("Estoque",typeof(string));

            // Adicionar Linhas 
            dataTableProdutos.Rows.Add("PROD123X31", "Pen Drive SanDisk USB Cruzer Blade ", "SIM");
            dataTableProdutos.Rows.Add("PRODCGRP71", "C3 Tech Headset Voicer Confort 6RC ", "SIM");
            dataTableProdutos.Rows.Add("PROD423G91", "Microsoft Mouse Óptico USB 200 35H ", "SIM");
            dataTableProdutos.Rows.Add("PROD213L32", "Multilaser Teclado Gamer Multimídia", "NÃO");
            dataTableProdutos.Rows.Add("PROD367L02", "Monitor LG LED 19,5 Polegadas Dual ", "NÃO");
          
            return dataTableProdutos;
        }

        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                #region Excel

                //Arquivo
                FileInfo fileInfo = new FileInfo(strCaminho);
                if (fileInfo.Exists)
                    fileInfo.Delete();

                using (ExcelPackage package = new ExcelPackage(fileInfo))
                {
                    #region Produtos

                    DataTable dtProdutos = Produtos();

                    if (dtProdutos.Rows.Count > 0)
                    {
                        //Total
                        int total = dtProdutos.Rows.Count;

                        //Variaveis Rows/Col
                        int ToRow = total + 1;
                        int ToCol = 3; //Total de colunas
                        int SumRow = ToRow + 1;

                        // Adiciona uma nova planilha para a pasta de trabalho vazia
                        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Contas");

                        #region Adicionar cabeçalhos a linha 1

                        //Adicionar os cabeçalhos
                        worksheet.Cells[1, 1].Value = "Código";
                        worksheet.Cells[1, 2].Value = "Produto";
                        worksheet.Cells[1, 3].Value = "Estoque";

                        //Formatando o estilo do cabeçalho Linha 1 
                        using (var range = worksheet.Cells[1, 1, 1, ToCol])
                        {
                            range.Style.Font.Bold = true;
                            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                            range.Style.Fill.BackgroundColor.SetColor(Color.DarkBlue);
                            range.Style.Font.Color.SetColor(Color.Azure);
                            range.Style.VerticalAlignment   = ExcelVerticalAlignment.Center;
                            range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        }

                        #endregion Adicionar cabeçalhos a linha 1

                        #region Adicionar itens nas células

                        int row = 1;
                        foreach (DataRow drProd in dtProdutos.Rows)
                        {
                            row++;

                            //Campos                                       
                            worksheet.SetValue(row, 1, drProd["Código"]);
                            worksheet.SetValue(row, 2, drProd["Produto"]);
                            worksheet.SetValue(row, 3, drProd["Estoque"]);
                        }
                        #endregion Adicionar itens nas células

                        //Formatar os valores
                        using (var range = worksheet.Cells[1, 1, ToRow, ToCol])
                        {
                            range.Style.VerticalAlignment   = ExcelVerticalAlignment.Center;
                            range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        }

                        using (var range = worksheet.Cells[1, 1, ToRow, ToCol])
                        {
                            range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                            range.Style.Border.Left.Color.SetColor(Color.FromArgb(0, 0, 0));
                            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                            range.Style.Border.Bottom.Color.SetColor(Color.FromArgb(0, 0, 0));
                        }

                        // Criar um filtro automático 
                        worksheet.Cells[1, 1, ToRow, ToCol].AutoFilter = true;

                        //Excel Congelar a linha 
                        worksheet.View.FreezePanes(2, 1);

                        #region Format type cells

                        //Format type cells
                        for (int i = 0; i < total; i++)
                        {
                            //Row
                            row = i + 1;

                            //Campos
                            worksheet.Cells[row, 1].Style.Numberformat.Format = "@";
                            worksheet.Cells[row, 2].Style.Numberformat.Format = "@";
                            worksheet.Cells[row, 3].Style.Numberformat.Format = "@";
                        }

                        #endregion Format type cells

                        //Autofit columns for all cells
                        worksheet.Cells.AutoFitColumns(0);

                        // Change the sheet view to show it in page layout mode
                        worksheet.View.PageLayoutView = false;
                    }

                    #endregion Produtos

                    //Definir propriedades do documento Detalhes/Descrição/Titutlo 
                    package.Workbook.Properties.Title = " Relatório dos Testes";

                    //Definir propriedades do documento Detalhes/Origem/Empresa
                    package.Workbook.Properties.Company = "Infofisco Serviços de Informática Ltda";

                    //Salvar
                    package.Save();
                }
                #endregion Excel
            }
            catch (ApplicationException ae)
            {
                //Mensagem de Alerta
                RadMessageBox.Show(ae.Message, "Alerta", MessageBoxButtons.OK, RadMessageIcon.Exclamation);
            }
            catch (Exception ex)
            {
                //Mensagem de Erro 
                RadMessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, RadMessageIcon.Error);
            }
        }
        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //Mensagem Processo Finalizado
            RadMessageBox.Show("Operação Relizada com Sucesso", "Informação", MessageBoxButtons.OK, RadMessageIcon.Info);
        }
    }
}
